
// let x = 10;
// let y = 20;
// let text = "x * y";
// let result = eval(text);

// alert(result);
alert("Adrian");