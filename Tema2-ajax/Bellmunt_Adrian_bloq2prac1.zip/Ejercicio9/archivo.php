<?php

echo("hola, gracias por la espera");

?>