$(document).ready(function() {
  $("h1").click(function() {
    $(".h1").animate({ color: "red" }, "slow");
  });
});


