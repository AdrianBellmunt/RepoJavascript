$(document).ready(function() {
    $("#boton").click(function(event) {
        $("#caja").load('pagina.html');
    });
});