<?php
$fecha = date('d/m/y');
print_r($fecha);
?>