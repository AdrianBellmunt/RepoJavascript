function mensaje() {
    $("#contenido").html("contenido del fichero JavaScript.");
}